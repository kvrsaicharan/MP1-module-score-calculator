class Login {
    getLogin() {
        return "getLogin() function of Login Class";
    }
    getLogout() {
        return "getLogout() function of Login Class";
    }
}
class Employee {

    getLogin() {
        return "getLogin() function of Employee Class";
    }
    getLogout() {
        return "getLogout() function of Employee Class";
    }
    constructor(empId, empName, empSalary, empDesignation) {
        this._empId_ = empId;
        this._empName_ = empName;
        this._empSalary_ = empSalary;
        this._empDesignation_ = empDesignation;

    }

    // Properties
    // employeeId

    get empId() {
        return this._empId_;
    }
    set empId(empId) {
        this._empId_ = empId;
    }

    // employeeName

    get empName() {
        return this._empName_;
    }
    set empName(empName) {
        this._empName_ = empName;
    }
    // employeeSalary

    get empSalary() {
        return this._empSalary_;
    }
    set empSalary(empSalary) {
        this._empSalary_ = empSalary;
    }

    // employeeDesignation

    get empDesignation() {
        return this._empDesignation_;
    }
    set empDesignation(empDesignation) {
        this._empDesignation_ = empDesignation;
    }

    // printDetails()function 

    printDetails() {
        let details = `Employee Details are
    Employee Id is ${this.empId}
    Employee Name is ${this.empName}
 
    Employee Designation is ${this.empDesignation}
    Employee Salary is ${this.empSalary}
    `;
        return details;
    }

} // end of Employee class

class EmployeeUtility {
    constructor() {

        // this.listEmpObject = new set();

        let empObj1 = new Employee(1002, 'Vikash', 9812, 'Consultant');
        let empObj2 = new Employee(1003, 'Amresh', 6661, 'Sr Consultant');
        let empObj3 = new Employee(1001, 'Uma', 10000, 'Sr Manager');
        let empObj4 = new Employee(1000, 'Vaishali', 9123, 'Manager');

        // create listEmpObject

        this.listEmpObject = new Set();

        //adding employee objects to array

        this.listEmpObject.add(empObj1);
        this.listEmpObject.add(empObj2);
        this.listEmpObject.add(empObj3);
        this.listEmpObject.add(empObj4);
    }

    // sort fun by empid

    sortByEmpId() {
        console.log("After sorting in ascending" + "order by emp id");
        let sortedSet =
            Array.from(this.listEmpObject).sort((e1, e2) => e1.empId - e2.empId);

        return sortedSet;


    }

    // getallemployees function

    getAllEmpolyees() {
        return this.listEmpObject;
    }

    // searchByEmpid() function

    searchByEmpId(id) {
        let searchedEmployee
            = Array.from(this.listEmpObject)
                .find(e => e.empId === id);


        return searchedEmployee;
    }

    // deleteByEmpid() function

    deleteByEmpId(id) {

        let deletedEmployee
            = Array.from(this.listEmpObject)
                .find(e => e.empId === id);
        this.listEmpObject.delete(deletedEmployee);
        return this.listEmpObject;


    }



}// end of EmployeeUtility


// this create list and adds employees to list

let utilityObj;

// print all the employees

console.log('Menu: ');
console.log('1- Add All Employees')
console.log('2- Show  all Employees ');
console.log('3- Sort by id');
console.log('4- Delete By Id');
console.log('0- Exit');

let choiceYN = 'N';
do {
    let choice = parseInt(prompt('Ur Choice:', 0));
    console.log(choice);
    switch (choice) {
        case 1: {
            utilityObj = new EmployeeUtility();
            console.log('Employee list is ready ..!');
        }
            break;

        //show all employees


        case 2: {
            let listEmpObject = utilityObj.getAllEmpolyees();
            for (let emp of listEmpObject) {
                console.log(emp.printDetails());
            }
        }
            break;

        //sort by emp id

        case 3: {

            let sortedlistEmpObject = utilityObj.sortByEmpId();
            for (let emp of sortedlistEmpObject) {
                console.log(emp.printDetails());
            }
        }
            break;

        // delete by empid

        case 4: {
            console.log("Current List of Employees");
            let listEmpObject
                = utilityObj.getAllEmpolyees();

            for (let emp of listEmpObject) {
                console.log(emp
                    .printDetails());
            }
            let id = parseInt(prompt('Employee Id: ', 0));
            let result = confirm("Are you sure wants to delete?");
            if (result) {

                //calling deleteByEmpId() function

                let newEmpListObj = utilityObj.deleteByEmpId(id);
                console.log("\nAfter deleting " + id);
                if (newEmpListObj != null) {

                    for (let emp of newEmpListObj) {
                        console.log(emp.printDetails());

                    }
                }
                else
                    console.log('Employee Id does not exist');
            }
        } break;

        // for exit

        case 0: {
            console.log("\n\n\tThank you..!");
            break;
        }
        default: {
            console.log("\n\n\tInvalid Choice ..!");
        }
            break;
    }
    choiceYN = prompt("Do you want to continue?", 'y');
    console.log(choiceYN);
} while (choiceYN === 'Y' || choiceYN === 'y');





// inheritance
// 1)using ---proto--
let empObj = new Employee();
let logObj = new Login();
//inheritance using ---proto---
empObj._proto_ = logObj;
console.log("logObj.getLogin():" + logObj.getLogin());
console.log("empObj.getLogin():" + empObj.getLogin());

//2)using ---object.create--
let logObj1 = new Login();
let empObj1 = new Employee();
//inheritance using object.create
empObj1 = Object.create(logObj1);
console.log("logObj1.getLogin():" + logObj1.getLogin());
console.log("empObj1.getLogin():" + Employee.prototype.getLogin());







