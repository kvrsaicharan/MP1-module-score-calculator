// function to load subjects at run time
// calling function with name
// declare the variables as var in the function
// check that var names must be started with lowercase letters

function getDomain(){
var domain = document.getElementById("chooseDomain");
var module = document.getElementById("chooseModule");

// this function is about to show the dropdown menu 

var selectedDomain = domain.options[domain.selectedIndex].value;
console.log(domain, ' ', module, ' ', selectedDomain);

// use if condtion for dropdown options
// if we select JEE the below options has to be shown in the Module

if(selectedDomain == "JEE"){

    module.options.length=0;
    module.options[0]= new Option("Select","Select");
    module.options[1]= new Option("CoreJAVA","Core JAVA");
    module.options[2]= new Option("Servlet-JSP","Servlet-JSP");
    module.options[3]= new Option("Spring","Spring");
}

    else  if(selectedDomain == "NET"){
        module.options.length=0;
        module.options[0]= new Option("Select","Select");
        module.options[1]= new Option("C#","CSharp");
        module.options[2]= new Option("ADO.NET","ADO.Net");
        module.options[3]= new Option("ASP.NET","ASP.Net");
    }
    else{
        module.options.length=0;
        module.options[0]= new Option("Select","Select");
    }

}
// function for showing the details of the calculated score in alert box 

function showDetails(frmModuleScoreCalc){
    if(frmModuleScoreCalc.checkValidity()){
    var name=frmModuleScoreCalc.txtName.value;   
    var mtp=parseInt(frmModuleScoreCalc.numMPTMarks.value);
    var mtt=parseInt(frmModuleScoreCalc.numMTTMarks.value);
    var ast=parseInt(frmModuleScoreCalc.numAssignMarks.value);
    var result=(mtp)+(mtt)+(ast);
    var details=
    "employee Name=" +name+ 
    "\nMPTMarks=" +mtp+ 
    "\nMTTMarks=" +mtt+ 
    "\nAssignMarks=" +ast+ 
    "total marks=" +result;
    alert(details);
}
}